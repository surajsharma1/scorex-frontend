import { Request, Response } from 'express';
import mongoose from 'mongoose';
import Club from '../models/Club';
import logger from '../utils/logger';
import { AuthRequest } from '../middleware/auth';

export const createClub = async (req: AuthRequest, res: Response) => {
  try {
    const { name, description } = req.body;
    const userId = req.user?._id;

    if (!name) {
      return res.status(400).json({ message: 'Club name is required' });
    }

    const club = new Club({
      name,
      description,
      members: [userId],
      createdBy: userId
    });

    await club.save();

    logger.info(`Club created: ${name} by ${userId}`);
    res.status(201).json({ message: 'Club created successfully', club });
  } catch (error: any) {
    if (error?.code === 11000) {
      return res.status(400).json({ message: 'Club name already exists' });
    }
    logger.error('Error creating club:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const getClubs = async (req: Request, res: Response) => {
  try {
    const clubs = await Club.find()
      .populate('members', 'username profilePicture')
      .populate('createdBy', 'username');

    res.json(clubs);
  } catch (error) {
    logger.error('Error getting clubs:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const searchClubs = async (req: Request, res: Response) => {
  try {
    const { query } = req.query;
    if (!query || typeof query !== 'string') {
      res.status(400).json({ message: 'Query parameter is required' });
      return;
    }

    const clubs = await Club.find({
      $or: [
        { name: { $regex: query, $options: 'i' } },
        { description: { $regex: query, $options: 'i' } }
      ]
    })
      .populate('members', 'username profilePicture')
      .populate('createdBy', 'username')
      .limit(10);

    res.json(clubs);
  } catch (error) {
    logger.error('Error searching clubs:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const getClub = async (req: Request, res: Response) => {
  try {
    const { clubId } = req.params;

    const club = await Club.findById(clubId)
      .populate('members', 'username profilePicture bio')
      .populate('createdBy', 'username');

    if (!club) {
      return res.status(404).json({ message: 'Club not found' });
    }

    res.json({ club });
  } catch (error) {
    logger.error('Error getting club:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const joinClub = async (req: AuthRequest, res: Response) => {
  try {
    const { clubId } = req.params;
    const userId = req.user?._id;

    const club = await Club.findById(clubId);
    if (!club) {
      return res.status(404).json({ message: 'Club not found' });
    }

    if (club.members.includes(userId)) {
      return res.status(400).json({ message: 'Already a member of this club' });
    }

    club.members.push(userId);
    await club.save();

    logger.info(`User ${userId} joined club ${clubId}`);
    res.json({ message: 'Joined club successfully', club });
  } catch (error) {
    logger.error('Error joining club:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const leaveClub = async (req: AuthRequest, res: Response) => {
  try {
    const { clubId } = req.params;
    const userId = req.user?._id;

    const club = await Club.findById(clubId);
    if (!club) {
      return res.status(404).json({ message: 'Club not found' });
    }

    if (!club.members.includes(userId)) {
      return res.status(400).json({ message: 'Not a member of this club' });
    }

    if (club.createdBy.toString() === userId) {
      return res.status(400).json({ message: 'Club creator cannot leave the club' });
    }

    club.members = club.members.filter(member => member.toString() !== userId);
    await club.save();

    logger.info(`User ${userId} left club ${clubId}`);
    res.json({ message: 'Left club successfully' });
  } catch (error) {
    logger.error('Error leaving club:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const updateClub = async (req: AuthRequest, res: Response) => {
  try {
    const { clubId } = req.params;
    const { name, description } = req.body;
    const userId = (req.user as any)?._id;

    const club = await Club.findById(clubId);
    if (!club) {
      return res.status(404).json({ message: 'Club not found' });
    }

    if (club.createdBy.toString() !== userId?.toString()) {
      return res.status(403).json({ message: 'Only club creator can update the club' });
    }

    if (name) club.name = name;
    if (description !== undefined) club.description = description;

    await club.save();

    logger.info(`Club updated: ${clubId}`);
    res.json({ message: 'Club updated successfully', club });
  } catch (error: any) {
    if (error.code === 11000) {
      return res.status(400).json({ message: 'Club name already exists' });
    }
    logger.error('Error updating club:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const deleteClub = async (req: AuthRequest, res: Response) => {
  try {
    const { clubId } = req.params;
    const userId = req.user?._id;

    const club = await Club.findById(clubId);
    if (!club) {
      return res.status(404).json({ message: 'Club not found' });
    }

    if (club.createdBy.toString() !== userId) {
      return res.status(403).json({ message: 'Only club creator can delete the club' });
    }

    await Club.findByIdAndDelete(clubId);

    logger.info(`Club deleted: ${clubId}`);
    res.json({ message: 'Club deleted successfully' });
  } catch (error) {
    logger.error('Error deleting club:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const addMember = async (req: AuthRequest, res: Response) => {
  try {
    const { clubId } = req.params;
    const { userId } = req.body;
    const currentUserId = req.user?._id;

    const club = await Club.findById(clubId);
    if (!club) {
      return res.status(404).json({ message: 'Club not found' });
    }

    if (club.createdBy.toString() !== currentUserId?.toString()) {
      return res.status(403).json({ message: 'Only club creator can add members' });
    }

    const userObjectId = new mongoose.Types.ObjectId(userId);
    if (club.members.some(member => member.toString() === userId)) {
      return res.status(400).json({ message: 'User is already a member of this club' });
    }

    club.members.push(userObjectId);
    await club.save();

    logger.info(`User ${userId} added to club ${clubId} by ${currentUserId}`);
    res.json({ message: 'Member added successfully', club });
  } catch (error) {
    logger.error('Error adding member:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const removeMember = async (req: AuthRequest, res: Response) => {
  try {
    const { clubId, userId } = req.params;
    const currentUserId = req.user?._id;

    const club = await Club.findById(clubId);
    if (!club) {
      return res.status(404).json({ message: 'Club not found' });
    }

    if (club.createdBy.toString() !== currentUserId?.toString()) {
      return res.status(403).json({ message: 'Only club creator can remove members' });
    }

    if (club.createdBy.toString() === userId) {
      return res.status(400).json({ message: 'Cannot remove the club creator' });
    }

    if (!club.members.some(member => member.toString() === userId)) {
      return res.status(400).json({ message: 'User is not a member of this club' });
    }

    club.members = club.members.filter(member => member.toString() !== userId);
    await club.save();

    logger.info(`User ${userId} removed from club ${clubId} by ${currentUserId}`);
    res.json({ message: 'Member removed successfully', club });
  } catch (error) {
    logger.error('Error removing member:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};
