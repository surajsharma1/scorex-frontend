import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import path from 'path';
import dotenv from 'dotenv';
import { createServer } from 'http';
import { Server } from 'socket.io';
import passport from 'passport';
import { Strategy as GoogleStrategy } from 'passport-google-oauth20';
import { Strategy as GitHubStrategy } from 'passport-github2';
import session from 'express-session';
import connectDB from './config/database';
import tournamentRoutes from './routes/tournaments';
import teamRoutes from './routes/teams';
import bracketRoutes from './routes/brackets';
import overlayRoutes from './routes/overlays';
import matchRoutes from './routes/matches';
import userRoutes from './routes/users';
import notificationRoutes from './routes/notifications';
import statsRoutes from './routes/stats';
import User from './models/User';
import jwt from 'jsonwebtoken';
import MongoStore from 'connect-mongo';
import authRoutes from './routes/auth';
import friendRoutes from './routes/friends';
import clubRoutes from './routes/clubs';
import paymentRoutes from './routes/payments';
import messageRoutes from './routes/messages';
import leaderboardRoutes from './routes/leaderboard';
import logger from './utils/logger';
import rateLimit from 'express-rate-limit';

dotenv.config();

const app = express();
const server = createServer(app);
export const io = new Server(server, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    methods: ['GET', 'POST'],
  },
});

// Connect to MongoDB
connectDB();

// Passport config
if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
  passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
     callbackURL: `${process.env.BACKEND_URL || 'http://localhost:5000'}/api/v1/auth/google/callback`,
  }, async (_accessToken, _refreshToken, profile, done) => {
    try {
      let user = await User.findOne({ googleId: profile.id });
      if (user) {
        done(null, user);
        return;
      }
      // Check if user exists by email
      const email = profile.emails?.[0].value;
      user = await User.findOne({ email });
      if (user) {
        // Associate Google ID with existing user
        user.googleId = profile.id;
        await user.save();
        done(null, user);
        return;
      }
      // New user: store pending info in session, don't create user yet
      const pendingGoogleUser = {
        googleId: profile.id,
        email,
        fullName: profile.displayName,
      };
      // Store in session for callback
      done(null, false, { pendingGoogleUser });
    } catch (error) {
      done(error, undefined);
    }
  }));
} else {
  console.warn('Google OAuth not configured.');
}

// GitHub OAuth
if (process.env.GITHUB_CLIENT_ID && process.env.GITHUB_CLIENT_SECRET) {
  passport.use(new GitHubStrategy({
    clientID: process.env.GITHUB_CLIENT_ID,
    clientSecret: process.env.GITHUB_CLIENT_SECRET,
    callbackURL: `${process.env.BACKEND_URL || 'http://localhost:5000'}/api/v1/auth/github/callback`,
  }, async (_accessToken: string, _refreshToken: string, profile: any, done: (error: any, user?: any) => void) => {
    try {
      let user = await User.findOne({ githubId: profile.id });
      if (user) {
        done(null, user);
        return;
      }
      // Check if user exists by email
      const email = profile.emails?.[0].value;
      user = await User.findOne({ email });
      if (user) {
        // Associate GitHub ID with existing user
        user.githubId = profile.id;
        await user.save();
        done(null, user);
        return;
      }
      // New user: create account
      user = await User.create({
        username: profile.username || profile.displayName,
        email,
        githubId: profile.id,
        role: 'viewer',
      });
      done(null, user);
    } catch (error) {
      done(error, undefined);
    }
  }));
} else {
  console.warn('GitHub OAuth not configured.');
}

passport.serializeUser((user: any, done) => done(null, user._id));
passport.deserializeUser(async (id, done) => {
  const user = await User.findById(id);
  done(null, user);
});

// Middleware
app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

// Debug middleware to log request bodies for troubleshooting
app.use((req, res, next) => {
  if (req.method === 'POST' || req.method === 'PUT') {
    console.log(`[${req.method}] ${req.path} - Content-Type: ${req.headers['content-type']}`);
    console.log('Request body:', req.body);
  }
  next();
});

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Trust proxy setting for rate limiting in production
app.set('trust proxy', 1);

// Session middleware added here
app.use(session({
  secret: process.env.SESSION_SECRET || 'fallback_secret_change_in_prod',
  store: MongoStore.create({ mongoUrl: process.env.MONGODB_URI }),
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    maxAge: 24 * 60 * 60 * 1000,
  },
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again later.',
});
app.use('/api/', limiter);

// Passport middleware
app.use(passport.initialize());
app.use(passport.session());

// Routes
app.use('/api/v1/tournaments', tournamentRoutes);
app.use('/api/v1/teams', teamRoutes);
app.use('/api/v1/brackets', bracketRoutes);
app.use('/api/v1/overlays', overlayRoutes);
app.use('/api/v1/matches', matchRoutes);
app.use('/api/v1/users', userRoutes);
app.use('/api/v1/notifications', notificationRoutes);
app.use('/api/v1/stats', statsRoutes);
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/friends', friendRoutes);
app.use('/api/v1/clubs', clubRoutes);
app.use('/api/v1/payments', paymentRoutes);
app.use('/api/v1/messages', messageRoutes);
app.use('/api/v1/leaderboard', leaderboardRoutes);

// Health check endpoint
app.get('/api/v1/health', async (req, res) => {
  try {
    // Check database connection
    const mongoose = require('mongoose');
    const dbStatus = mongoose.connection.readyState === 1 ? 'connected' : 'disconnected';

    // Check Redis connection
    const cacheService = require('./utils/cache').cacheService;
    const redisStatus = cacheService.isConnected ? 'connected' : 'disconnected';

    res.status(200).json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      services: {
        database: dbStatus,
        redis: redisStatus,
      },
      uptime: process.uptime(),
    });
  } catch (error) {
    res.status(503).json({
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      error: (error as Error).message,
    });
  }
});

// Serve overlays from frontend public folder - use path.resolve for reliability
const overlaysPath = path.resolve(__dirname, '../../scorex-frontend/scorex-frontend/public/overlays');
app.use('/overlays', express.static(overlaysPath));
app.use('/overlay', express.static(overlaysPath)); // Legacy path support

// Socket.io
io.on('connection', (socket) => {
  logger.info(`User connected: ${socket.id}`);

  // Join tournament room for real-time score updates
  socket.on('joinTournament', (tournamentId: string) => {
    socket.join(tournamentId);
    logger.info(`User ${socket.id} joined tournament: ${tournamentId}`);
  });

  // Leave tournament room
  socket.on('leaveTournament', (tournamentId: string) => {
    socket.leave(tournamentId);
    logger.info(`User ${socket.id} left tournament: ${tournamentId}`);
  });

  // Join match room for detailed updates
  socket.on('joinMatch', (matchId: string) => {
    socket.join(`match:${matchId}`);
    logger.info(`User ${socket.id} joined match: ${matchId}`);
  });

  // Leave match room
  socket.on('leaveMatch', (matchId: string) => {
    socket.leave(`match:${matchId}`);
    logger.info(`User ${socket.id} left match: ${matchId}`);
  });

  // Update score - broadcast to all users in the tournament
  socket.on('updateScore', (data: { tournamentId: string; match: any }) => {
    io.to(data.tournamentId).emit('scoreUpdate', data);
    logger.info(`Score update for tournament ${data.tournamentId}:`, data.match);
  });

  // Match status update - broadcast to all users in the match
  socket.on('updateMatchStatus', (data: { matchId: string; tournamentId: string; status: string }) => {
    io.to(`match:${data.matchId}`).emit('matchStatusUpdate', data);
    io.to(data.tournamentId).emit('matchStatusUpdate', data);
    logger.info(`Match status update: ${data.matchId} - ${data.status}`);
  });

  // Tournament update - broadcast to all users in the tournament
  socket.on('updateTournament', (data: { tournamentId: string; tournament: any }) => {
    io.to(data.tournamentId).emit('tournamentUpdate', data);
    logger.info(`Tournament update for ${data.tournamentId}:`, data.tournament);
  });

  // Live notification - broadcast to all connected users
  socket.on('sendNotification', (data: { userId?: string; message: string; type: string }) => {
    if (data.userId) {
      // Send to specific user
      io.to(`user:${data.userId}`).emit('notification', data);
    } else {
      // Broadcast to all users
      io.emit('notification', data);
    }
    logger.info(`Notification sent: ${data.type} - ${data.message}`);
  });

  // Join user-specific room for notifications
  socket.on('joinUserRoom', (userId: string) => {
    socket.join(`user:${userId}`);
    logger.info(`User ${socket.id} joined user room: ${userId}`);
  });

  // Handle typing indicators for chat
  socket.on('typing', (data: { roomId: string; userId: string; isTyping: boolean }) => {
    socket.to(data.roomId).emit('userTyping', data);
  });

  // Handle chat messages
  socket.on('sendMessage', (data: { roomId: string; message: any }) => {
    io.to(data.roomId).emit('newMessage', data.message);
    logger.info(`New message in room ${data.roomId}`);
  });

  // Disconnect handling
  socket.on('disconnect', () => {
    logger.info(`User disconnected: ${socket.id}`);
  });
});

// Error handling
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  logger.error('Unhandled error:', err);
  res.status(500).json({ message: 'Something went wrong!' });
});

const PORT = process.env.PORT || 5000;
console.log(`Starting server on port ${PORT}`);
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

app.get('/api/auth/auto-login', async (req, res) => {
  const user = await User.findOne({ email: 'default@example.com' });
  if (!user) {
    const newUser = await User.create({ username: 'Default', email: 'default@example.com', password: 'password', role: 'admin' });
    const token = jwt.sign({ id: newUser._id }, process.env.JWT_SECRET!);
    return res.json({ token });
  }
  const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET!);
  res.json({ token });
});

export default app;
